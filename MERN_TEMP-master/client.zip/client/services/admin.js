class adminService{
    createUser(newUserData,callback){
        console.log(newUserData);
        fetch("http://localhost:8080/users/createUser",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(newUserData)
            }).then(response => response.json())
            .then(resData => {
                callback(null,{'Flag':'True'});
            });
    }
    getUserData(callback){
        fetch("http://localhost:8080/users/getTemporaryUsers",
            {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(response => response.json())
            .then(resData => {
                console.log("result",resData);
                callback(null,{'Flag':'True'});
            });
        
    } 
}

export default adminService;