import React, { Component } from "react";
import history from '../history';
import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Button
} from 'reactstrap';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

class HeaderComponent extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <Navbar color="dark" light expand="md">
                    <NavbarBrand href="/"><font color="white">Home</font></NavbarBrand>
                    <Nav className="ml-auto" navbar>
                        <NavItem>
                            <NavLink href="/"><font color="white">Logout</font></NavLink>
                        </NavItem>
                    </Nav>
                </Navbar>
            </div>
        );
    }
}

export class AdminHeaderComponent extends Component {
    constructor(props) {
        super(props);
    }

    createUser(){
        history.push('/createUser');
    }
    render() {
        return (
            <div>
                <Navbar color="dark" light expand="md">
                    <NavbarBrand href="/"><font color="white">Home</font></NavbarBrand>
                    <Button color="link" onClick={this.createUser}><font color="white">Create User</font></Button>
                    <Nav className="ml-auto" navbar>
                        <UncontrolledDropdown nav inNavbar left>
                            <DropdownToggle nav caret>
                            <font color="white">Options</font>
                            </DropdownToggle>
                            <DropdownMenu left>
                                <DropdownItem>
                               Create Role  
                  </DropdownItem>
                                <DropdownItem>
                                My Profile   
                  </DropdownItem>
                            </DropdownMenu>
                        </UncontrolledDropdown>
                        <NavItem>
                            <NavLink href="/"><font color="white">Logout</font></NavLink>
                        </NavItem>
                    </Nav>
                </Navbar>
            </div>
        );
    }
}

export default HeaderComponent;