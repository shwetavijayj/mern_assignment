import React, { Component } from "react";
import { InputGroup, Input, Button } from 'reactstrap';
import { AdminHeaderComponent } from './header.jsx';
import  adminService  from '../services/admin.js';
class UserlistComponent extends Component {
    constructor(props) {
        super(props);
        //this.state logic goes here
        this.serve = new adminService();
    }
    componentDidMount(){
        // console.log("Hello");
        this.serve.getUserData((err,res)=>{
            if(err){
                console.log("Please redirect to appropriate page.");
            }else{
                console.log("res",res);
            }
        });
    }
    render() {
        
        return (
            <div>
                <AdminHeaderComponent></AdminHeaderComponent>
                <div className="container col-sm-6" style={{ 'paddingTop': '50px' }}>
                   
                   
                </div>
            </div>
        );
    }
}

export default UserlistComponent;