var mongo = require('../mongoConnect');
personModel = mongo.mongoose.model("personalSchema", mongo.personalSchema, "PersonalInfo");
personModelTemp = mongo.mongoose.model("personalSchemaTemp", mongo.personalSchemaTemp, "PersonalInfoPortalTemp");


/*
    this api will return information of user to display it on home-page
*/
function getUserInfo(data, callback) {
    condition = {
        UserId: parseInt(data.UserId)
    }
    personModel.findOne(condition, function (err, res) {
        if (err) {
            callback(err);
        }
        else {
            callback(null, res);
        }
    });
}


/*
Admin purpose
this api will return information of all users
*/
function getAllUserInformation(callback) {
    personModel.find(function (err, res) {
        if (err) {
            callback(err);
        }
        else {
            callback(null, res);
        }
    })
}

/*
Admin purpose
this api will return information of all users from temporary user
*/
function getAllTempUsersInformation(callback) {
    personModelTemp.find(function (err, res) {
        if (err) {
            callback(err);
        } else {
            getFormattedData(res,(err,result)=>{
                if(err){
                    callback(err);
                }
                else{
                    callback(null,result);
                }
            })
           
        }
    })
}

function getFormattedData(data,callback){
    console.log(data);
    let result=[];
    data.forEach(element => {
        result.push({
            Address:{
                Addr1: element.Address.addr1,
                Addr2: element.Address.addr2,
                Addr3: element.Address.addr3
            },
            Age:
            Birthsign:
            City:,
            DateOfBirth:,

        })
       
    });
    callback(null,result);
}

module.exports = {
    getUserInfo,
    getAllUserInformation,
    getAllTempUsersInformation
}